# Quickstart

The ARCHES PiCar-X can be run via Docker. Follow our [quickstart guide](https://cau-se.github.io/ARCHES-PiCar-X/getting_started.html) to get started.