The original .DAE files for the Gazebo model are taken from [Theosakamg Github](https://github.com/Theosakamg/PiCar_Hardware). We use the parts of the PiCar-V and PiCar-S for the PiCar-X.

