---
title: Installation MacOs
has_children: false
parent: Installation
nav_order: 3
---

# Installation on MacOs
This example will not work on MacOs, since relevant kernel modules are missing (i2c-stub and gpio-mockup).