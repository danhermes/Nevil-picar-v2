from setuptools import setup, find_packages

setup(name = 'picarx_dcmotor_emulator',
  packages=find_packages('picarx_dcmotor_emulator'),
  package_dir={'': 'src'},
  install_requires=[]
)
