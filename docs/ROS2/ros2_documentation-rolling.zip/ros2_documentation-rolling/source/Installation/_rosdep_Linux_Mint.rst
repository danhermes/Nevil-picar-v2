**Note**: If you're using a distribution that is based on Ubuntu (like Linux Mint) but does not identify itself as such, you'll get an error message like ``Unsupported OS [mint]``.
In this case append ``--os=ubuntu:noble`` to the above command.
