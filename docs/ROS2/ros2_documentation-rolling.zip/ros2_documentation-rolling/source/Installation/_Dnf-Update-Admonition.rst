ROS 2 packages are built on frequently updated RHEL systems.
It is always recommended that you ensure your system is up to date before installing new packages.

.. code-block:: console

   $ sudo dnf update
