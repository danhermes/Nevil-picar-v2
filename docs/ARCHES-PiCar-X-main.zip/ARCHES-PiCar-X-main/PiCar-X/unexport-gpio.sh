echo 23 > /sys/class/gpio/unexport
echo 24 > /sys/class/gpio/unexport