.. redirect-from::

   Concepts/About-Composition

Composition
===========

.. contents:: Table of Contents
   :local:

ROS 1 - Nodes vs. Nodelets
--------------------------

In ROS 1 you can write your code either as a `ROS node <https://wiki.ros.org/Nodes>`__ or as a `ROS nodelet <https://wiki.ros.org/nodelet>`__.
ROS 1 nodes are compiled into executables.
ROS 1 nodelets on the other hand are compiled into a shared library which is then loaded at runtime by a container process.

ROS 2 - Unified API
-------------------

In ROS 2 the recommended way of writing your code is similar to a nodelet - we call it a ``Component``.
This makes it easy to add common concepts to existing code, like a `life cycle <https://design.ros2.org/articles/node_lifecycle.html>`__.
Having different APIs, which was the biggest drawback in ROS 1, is avoided in ROS 2 since both approaches use the same API.

.. note::

   It is still possible to use the node-like style of "writing your own main" but for the common case it is not recommended.

By making the process layout a deploy-time decision the user can choose between:

* running multiple nodes in separate processes with the benefits of process/fault isolation as well as easier debugging of individual nodes and
* running multiple nodes in a single process with the lower overhead and optionally more efficient communication (see :doc:`Intra Process Communication <../../Tutorials/Demos/Intra-Process-Communication>`).

Additionally ``ros2 launch`` can be used to automate these actions through specialized launch actions.

.. _ComponentContainer:

Component Container
-------------------

A component container is a host process that allows you to load and manage multiple components at runtime within the same process space.

As of now, the following generic component container types are available:

* `component_container <https://github.com/ros2/rclcpp/blob/{REPOS_FILE_BRANCH}/rclcpp_components/src/component_container.cpp>`__

  * The most generic component container that uses a single ``SingleThreadedExecutor`` to execute all components.

* `component_container_mt <https://github.com/ros2/rclcpp/blob/{REPOS_FILE_BRANCH}/rclcpp_components/src/component_container_mt.cpp>`__

  * Component container that uses a single ``MultiThreadedExecutor`` to execute the components.

* `component_container_isolated <https://github.com/ros2/rclcpp/blob/{REPOS_FILE_BRANCH}/rclcpp_components/src/component_container_isolated.cpp>`__

  * Component container that uses a dedicated executor for each component: either ``SingleThreadedExecutor`` (default) or ``MultiThreadedExecutor``.

For more information about the types of executors, see the :ref:`TypesOfExecutors`.
For more information about the options of each component container, see :ref:`ComponentContainerTypes` in the composition tutorial.

Writing a Component
-------------------

Since a component is only built into a shared library, it doesn't have a ``main`` function (see `Talker source code <https://github.com/ros2/demos/blob/{REPOS_FILE_BRANCH}/composition/src/talker_component.cpp>`__).
A component is commonly a subclass of ``rclcpp::Node``.
Since it is not in control of the thread, it shouldn't perform any long running or blocking tasks in its constructor.
Instead, it can use timers to get periodic notifications.
Additionally, it can create publishers, subscriptions, servers, and clients.

An important aspect of making such a class a component is that the class registers itself using macros from the package ``rclcpp_components`` (see the last line in the source code).
This makes the component discoverable when its library is being loaded into a running process - it acts as kind of an entry point.

Additionally, once a component is created, it must be registered with the index to be discoverable by the tooling.

.. code-block:: cmake

   add_library(talker_component SHARED src/talker_component.cpp)
   rclcpp_components_register_nodes(talker_component "composition::Talker")
   # To register multiple components in the same shared library, use multiple calls
   # rclcpp_components_register_nodes(talker_component "composition::Talker2")

For an example, :doc:`check out this tutorial <../../Tutorials/Intermediate/Writing-a-Composable-Node>`

.. note::

   In order for the component_container to be able to find desired components, it must be executed or launched from a shell that has sourced the corresponding workspace.

Using Components
----------------

The `composition <https://github.com/ros2/demos/tree/{REPOS_FILE_BRANCH}/composition>`__ package contains a couple of different approaches on how to use components.
The three most common ones are:

#. Start a (`generic container process <https://github.com/ros2/rclcpp/blob/{REPOS_FILE_BRANCH}/rclcpp_components/src/component_container.cpp>`__) and call the ROS service `load_node <https://github.com/ros2/rcl_interfaces/blob/{REPOS_FILE_BRANCH}/composition_interfaces/srv/LoadNode.srv>`__ offered by the container.
   The ROS service will then load the component specified by the passed package name and library name and start executing it within the running process.
   Instead of calling the ROS service programmatically you can also use a `command line tool <https://github.com/ros2/ros2cli/tree/{REPOS_FILE_BRANCH}/ros2component>`__ to invoke the ROS service with the passed command line arguments
#. Create a `custom executable <https://github.com/ros2/demos/blob/{REPOS_FILE_BRANCH}/composition/src/manual_composition.cpp>`__ containing multiple nodes which are known at compile time.
   This approach requires that each component has a header file (which is not strictly needed for the first case).
#. Create a launch file and use ``ros2 launch`` to create a container process with multiple components loaded.

Practical application
---------------------

Try the :doc:`Composition demos <../../Tutorials/Intermediate/Composition>`.
