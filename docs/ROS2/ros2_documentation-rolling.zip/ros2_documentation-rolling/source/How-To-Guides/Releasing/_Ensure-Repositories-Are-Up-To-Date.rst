Make sure that:

* Your repository is hosted on a remote such as GitHub.
* You have a clone of the repository on your computer and are on the right branch.
* Both the remote repository and your clone are up-to-date.
