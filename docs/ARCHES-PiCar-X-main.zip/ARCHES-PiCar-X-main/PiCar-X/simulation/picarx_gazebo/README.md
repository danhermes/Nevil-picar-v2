# How to start the model in Gazebo

roslaunch picarx_dcmotor_driver dcmotor_driver.launch name:=motor-left direction_pin:=24 pwm_pin:=P12 motor_side:=0