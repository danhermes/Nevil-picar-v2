.. redirect-from::

    Managed-Nodes
    Tutorials/Managed-Nodes

Managing nodes with managed lifecycles
======================================

This page lives now directly side-by-side with the `code <https://github.com/ros2/demos/blob/{REPOS_FILE_BRANCH}/lifecycle/README.rst>`__.
For more information about the ``lifecycle`` package, refer to `rosindex <https://index.ros.org/p/lifecycle/>`__.
